# Gestión de Cine

Aplicación Front-End que permite explorar la cartelera de un cine, buscar y filtrar películas, ver el detalle de cada una y reservar una función disponible.

Proyecto desarrollado para la evaluación **Desarrollo Front-End con React** de la asignatura Desarrollo de Aplicaciones Web.

## Integrantes
- Esteban Droppelman
- Pablo Muñoz

## Funcionalidades principales
- Listado dinámico de la cartelera de películas.
- Búsqueda por título y filtro por género.
- Vista de detalle con sinopsis, duración y clasificación.
- Selección de función (día, hora y sala) con control de cupos.
- Reserva de función con confirmación.
- Carga de datos simulando una petición a una API (loading state incluido).
- Diseño responsivo con Bootstrap.

## Tecnologías utilizadas
- React 18 + Vite
- JavaScript (JSX)
- Bootstrap 5
- Google Fonts (Bebas Neue, Inter)

## Cómo ejecutar el proyecto localmente
```bash
# 1. Clonar el repositorio
git clone https://github.com/droppelBoy/gestion-cine.git
cd gestion-cine

# 2. Instalar dependencias
npm install

# 3. Levantar el servidor de desarrollo
npm run dev
```
La aplicación quedará disponible en `http://localhost:5173`.

## Próxima etapa
Este proyecto será extendido con un Back-End y API REST propia en la siguiente evaluación de la asignatura.
