import { useState, useEffect, useMemo } from 'react'
import Navbar from './components/Navbar.jsx'
import SearchFilter from './components/SearchFilter.jsx'
import MovieList from './components/MovieList.jsx'
import MovieDetail from './components/MovieDetail.jsx'
import { fetchMovies } from './data/movies.js'

function App() {
  // Estado de los datos "traídos de la API simulada"
  const [peliculas, setPeliculas] = useState([])
  const [cargando, setCargando] = useState(true)

  // Estado de la interfaz
  const [search, setSearch] = useState('')
  const [genero, setGenero] = useState('')
  const [peliculaSeleccionadaId, setPeliculaSeleccionadaId] = useState(null)

  // useEffect + fetchMovies: simula la petición a una API al montar el componente.
  useEffect(() => {
    fetchMovies().then((data) => {
      setPeliculas(data)
      setCargando(false)
    })
  }, [])

  // Lista de géneros únicos para el select, calculada a partir de los datos
  const generosDisponibles = useMemo(
    () => [...new Set(peliculas.map((p) => p.genero))],
    [peliculas],
  )

  // Filtrado dinámico: se recalcula cada vez que cambian search, genero o peliculas
  const peliculasFiltradas = useMemo(() => {
    return peliculas.filter((p) => {
      const coincideTexto = p.titulo.toLowerCase().includes(search.toLowerCase())
      const coincideGenero = genero === '' || p.genero === genero
      return coincideTexto && coincideGenero
    })
  }, [peliculas, search, genero])

  const peliculaSeleccionada = peliculas.find((p) => p.id === peliculaSeleccionadaId)

  return (
    <>
      <Navbar />
      <main className="container py-4">
        {peliculaSeleccionada ? (
          <MovieDetail
            pelicula={peliculaSeleccionada}
            onVolver={() => setPeliculaSeleccionadaId(null)}
          />
        ) : (
          <>
            <SearchFilter
              search={search}
              onSearchChange={setSearch}
              genero={genero}
              onGenreChange={setGenero}
              generosDisponibles={generosDisponibles}
            />

            {cargando ? (
              <p className="loading-text">Cargando cartelera...</p>
            ) : (
              <MovieList
                peliculas={peliculasFiltradas}
                onSelect={setPeliculaSeleccionadaId}
              />
            )}
          </>
        )}
      </main>
    </>
  )
}

export default App
