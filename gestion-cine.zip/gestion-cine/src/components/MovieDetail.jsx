import { useState } from 'react'
import FunctionSelector from './FunctionSelector.jsx'
import BookingConfirmation from './BookingConfirmation.jsx'

// MovieDetail es la vista de detalle. Guarda en su propio estado
// qué función fue elegida, y solo cuando hay una selección
// renderiza el componente de confirmación (composición condicional).
function MovieDetail({ pelicula, onVolver }) {
  const [funcionSeleccionada, setFuncionSeleccionada] = useState(null)

  return (
    <div className="detail-panel">
      <span className="back-link" onClick={onVolver}>
        &larr; Volver a la cartelera
      </span>

      <div className="row">
        <div className="col-md-4 mb-3">
          <div className="poster-wrap" style={{ borderRadius: '4px' }}>
            {pelicula.titulo}
          </div>
        </div>
        <div className="col-md-8">
          <h2 className="display-font" style={{ fontSize: '2rem' }}>
            {pelicula.titulo}
          </h2>
          <p className="meta mb-2">
            {pelicula.genero} &middot; {pelicula.duracion} min &middot; {pelicula.clasificacion}
          </p>
          <p>{pelicula.sinopsis}</p>
        </div>
      </div>

      <hr style={{ borderColor: 'var(--border)' }} />

      <FunctionSelector
        funciones={pelicula.funciones}
        funcionSeleccionada={funcionSeleccionada}
        onSelectFuncion={setFuncionSeleccionada}
      />

      {funcionSeleccionada && (
        <BookingConfirmation pelicula={pelicula} funcion={funcionSeleccionada} />
      )}
    </div>
  )
}

export default MovieDetail
