import { useState } from 'react'

// BookingConfirmation es la "funcionalidad adicional" pedida por la pauta:
// una reserva. Tiene su propio useState para saber si ya fue confirmada.
function BookingConfirmation({ pelicula, funcion }) {
  const [confirmada, setConfirmada] = useState(false)

  if (confirmada) {
    return (
      <div className="confirm-box mt-4">
        <p className="mb-1 fw-semibold" style={{ color: 'var(--gold)' }}>
          ¡Reserva confirmada!
        </p>
        <p className="mb-0 text-muted">
          {pelicula.titulo} &middot; {funcion.dia} {funcion.hora} &middot; {funcion.sala}
        </p>
      </div>
    )
  }

  return (
    <div className="confirm-box mt-4">
      <p className="mb-2">
        Vas a reservar <strong>{pelicula.titulo}</strong> para el {funcion.dia} a las{' '}
        {funcion.hora} en {funcion.sala}.
      </p>
      <button className="btn-gold" onClick={() => setConfirmada(true)}>
        Confirmar reserva
      </button>
    </div>
  )
}

export default BookingConfirmation
