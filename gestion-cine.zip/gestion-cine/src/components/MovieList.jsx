import MovieCard from './MovieCard.jsx'

// MovieList recibe el arreglo ya filtrado y lo recorre con .map()
// para renderizar un MovieCard por cada película: esto es el
// "listado dinámico de información" que pide la pauta.
function MovieList({ peliculas, onSelect }) {
  if (peliculas.length === 0) {
    return <p className="text-muted">No se encontraron películas con ese criterio.</p>
  }

  return (
    <div className="row">
      {peliculas.map((pelicula) => (
        <MovieCard key={pelicula.id} pelicula={pelicula} onSelect={onSelect} />
      ))}
    </div>
  )
}

export default MovieList
