// Navbar: componente simple, sin props por ahora.
// Solo muestra el nombre de la app.
function Navbar() {
  return (
    <header className="cine-navbar">
      <h1 className="brand">
        GESTIÓN<span>·CINE</span>
      </h1>
    </header>
  )
}

export default Navbar
