// SearchFilter maneja su propio estado de texto y género,
// pero cada cambio lo "sube" al componente padre (App) mediante props
// de tipo función (onSearchChange, onGenreChange). Este patrón se llama
// "lifting state up".
function SearchFilter({ search, onSearchChange, genero, onGenreChange, generosDisponibles }) {
  return (
    <div className="filter-bar mb-4">
      <div className="row g-2">
        <div className="col-md-8">
          <input
            type="text"
            className="form-control"
            placeholder="Buscar película por título..."
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <select
            className="form-select"
            value={genero}
            onChange={(e) => onGenreChange(e.target.value)}
          >
            <option value="">Todos los géneros</option>
            {generosDisponibles.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  )
}

export default SearchFilter
