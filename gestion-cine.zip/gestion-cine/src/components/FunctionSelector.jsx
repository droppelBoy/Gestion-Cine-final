// FunctionSelector muestra los horarios disponibles de una película
// y maneja cuál función está seleccionada. El id seleccionado vive
// en el padre (MovieDetail) para que la confirmación pueda usarlo también.
function FunctionSelector({ funciones, funcionSeleccionada, onSelectFuncion }) {
  return (
    <div>
      <h3 className="h6 text-uppercase mb-3" style={{ color: 'var(--gold)' }}>
        Funciones disponibles
      </h3>
      <div className="d-flex flex-wrap gap-2">
        {funciones.map((funcion) => {
          const sinCupo = funcion.asientosDisponibles === 0
          const seleccionada = funcionSeleccionada?.id === funcion.id
          return (
            <button
              key={funcion.id}
              type="button"
              disabled={sinCupo}
              className={`function-btn ${seleccionada ? 'selected' : ''}`}
              onClick={() => onSelectFuncion(funcion)}
            >
              {funcion.dia} &middot; {funcion.hora} &middot; {funcion.sala}
              <br />
              <small>{sinCupo ? 'Sin cupos' : `${funcion.asientosDisponibles} asientos`}</small>
            </button>
          )
        })}
      </div>
    </div>
  )
}

export default FunctionSelector
