// MovieCard recibe una película por props y avisa al padre (mediante
// el evento onClick) cuál película fue seleccionada. No maneja estado propio.
function MovieCard({ pelicula, onSelect }) {
  return (
    <div className="col-sm-6 col-md-4 col-lg-3 mb-4">
      <div className="movie-card" onClick={() => onSelect(pelicula.id)}>
        <div className="poster-wrap">{pelicula.titulo}</div>
        <div className="card-body">
          <p className="card-title">{pelicula.titulo}</p>
          <p className="meta">{pelicula.duracion} min &middot; {pelicula.clasificacion}</p>
          <span className="badge-genre">{pelicula.genero}</span>
        </div>
      </div>
    </div>
  )
}

export default MovieCard
