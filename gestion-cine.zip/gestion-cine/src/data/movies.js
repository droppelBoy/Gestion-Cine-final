// Datos simulados de la cartelera.
// En la próxima etapa (Back-End) esto vendrá de una API real vía fetch.
export const movies = [
  {
    id: 1,
    titulo: 'Horizonte Perdido',
    genero: 'Ciencia ficción',
    duracion: 128,
    clasificacion: 'TE',
    sinopsis:
      'Una tripulación despierta de un sueño criogénico a bordo de una nave que ya no reconoce, obligada a descubrir qué ocurrió durante los años que durmieron.',
    funciones: [
      { id: 101, sala: 'Sala 1', dia: '2026-09-15', hora: '17:30', asientosDisponibles: 12 },
      { id: 102, sala: 'Sala 3', dia: '2026-09-15', hora: '20:15', asientosDisponibles: 4 },
      { id: 103, sala: 'Sala 1', dia: '2026-09-16', hora: '19:00', asientosDisponibles: 0 },
    ],
  },
  {
    id: 2,
    titulo: 'El Último Vals',
    genero: 'Drama',
    duracion: 104,
    clasificacion: 'TE+7',
    sinopsis:
      'Un antiguo bailarín de tango regresa a su barrio natal para enseñar a un grupo de jóvenes, y en el camino aprende a reconciliarse con su propio pasado.',
    funciones: [
      { id: 201, sala: 'Sala 2', dia: '2026-09-15', hora: '18:00', asientosDisponibles: 20 },
      { id: 202, sala: 'Sala 2', dia: '2026-09-17', hora: '21:00', asientosDisponibles: 9 },
    ],
  },
  {
    id: 3,
    titulo: 'Código Rojo',
    genero: 'Acción',
    duracion: 116,
    clasificacion: 'TE+14',
    sinopsis:
      'Una analista de ciberseguridad descubre una brecha en el sistema bancario nacional y tiene 24 horas para detenerla antes del colapso financiero.',
    funciones: [
      { id: 301, sala: 'Sala 4', dia: '2026-09-16', hora: '16:45', asientosDisponibles: 15 },
      { id: 302, sala: 'Sala 4', dia: '2026-09-16', hora: '22:00', asientosDisponibles: 2 },
      { id: 303, sala: 'Sala 1', dia: '2026-09-18', hora: '19:30', asientosDisponibles: 18 },
    ],
  },
  {
    id: 4,
    titulo: 'Risas de Medianoche',
    genero: 'Comedia',
    duracion: 95,
    clasificacion: 'TE',
    sinopsis:
      'Cuatro amigos organizan la peor despedida de soltero de la historia en una sola noche que se sale completamente de control.',
    funciones: [
      { id: 401, sala: 'Sala 3', dia: '2026-09-15', hora: '22:30', asientosDisponibles: 25 },
      { id: 402, sala: 'Sala 5', dia: '2026-09-19', hora: '20:00', asientosDisponibles: 11 },
    ],
  },
  {
    id: 5,
    titulo: 'La Sombra del Bosque',
    genero: 'Terror',
    duracion: 99,
    clasificacion: 'TE+18',
    sinopsis:
      'Un grupo de excursionistas se pierde en un bosque donde las señales de celular no funcionan y las huellas nunca son suyas.',
    funciones: [
      { id: 501, sala: 'Sala 2', dia: '2026-09-16', hora: '23:00', asientosDisponibles: 7 },
      { id: 502, sala: 'Sala 4', dia: '2026-09-18', hora: '21:45', asientosDisponibles: 0 },
    ],
  },
  {
    id: 6,
    titulo: 'Mundo Diminuto',
    genero: 'Animación',
    duracion: 88,
    clasificacion: 'TE',
    sinopsis:
      'Una hormiga inventora construye una máquina para hablar con los humanos, y descubre que su jardín es mucho más grande de lo que imaginaba.',
    funciones: [
      { id: 601, sala: 'Sala 5', dia: '2026-09-15', hora: '15:00', asientosDisponibles: 30 },
      { id: 602, sala: 'Sala 5', dia: '2026-09-17', hora: '17:15', asientosDisponibles: 22 },
    ],
  },
]

// Simula una petición a una API: devuelve una Promise que resuelve
// después de un pequeño retraso, tal como lo haría un fetch real.
export function fetchMovies() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(movies)
    }, 800)
  })
}
